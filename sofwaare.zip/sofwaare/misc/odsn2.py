# Input
foo = [4, 42, 1337, 9, 2, 6, 7, 21, 26, 5, 314]
print (foo)
print ("")

# Processing
#total = []
#numb = 1
#if numb < 11:
#    foo[0]+foo[numb]
#    numb =+ 1

total = 0
for i in foo:
    total = total + i

# Output
print(total)