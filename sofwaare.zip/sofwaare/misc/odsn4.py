# Input
foo = [4, 42, 1337, 9, 2, 6, 7, 21, 26, 5, 314]
print (foo)
print ("")
numb = input("type a number: ")
number = int(numb)

# Processing
bigger = []
for i in foo:
    if i > number:
        bigger.append(1)

if len(bigger) >= 1:
    print("true")
else:
    print("false")
        
#    else:
#        print("False")

# Output
