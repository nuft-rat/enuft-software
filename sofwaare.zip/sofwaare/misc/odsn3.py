# Input
foo = [4, 42, 1337, 9, 2, 6, 7, 21, 26, 5, 314]
print (foo)
tof = input("even or odd? ")
print ("")

# Processing
for i in foo:
    if tof == "even":
        if i % 2 == 0:
            print("true")
        else:
            print("false")
    else:
        if i % 2 == 1:
            print("true")
        else:
            print("false")

# Output
