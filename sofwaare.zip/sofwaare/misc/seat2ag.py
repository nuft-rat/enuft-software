# Adventure game
# Created by : Nuft   Version : 1.0.0    Date : 11/5/26
import pygame

pygame.init()

# Globals


# Classes
# Adventurer
class Adventurer : 
    def __init__ (self) : 
        self.room = 0
        self.objects = []
        
    # Set up the character
    def set_up_character (self) :
        self.name = input("What is your name brave adventurer? ")
        self.gender = input("Are you male (m) or female (f)? ")
        
        self.age = int(input("And finally, how old are you? "))
        while self.__validate_age(self.age) == False :
            print ("Either you entered an age which is too old or too young.")
            self.age = int(input("How old are you? "))
     
    
    def __validate_age (self, age) :
        if age < 0 or age > 100 :
            return False
        else :
            return True

        
    def describe (self) :
        print (f"Your name : {self.name}")
        print (f"Your gender : {self.gender}")
        print (f"Your age : {self.age}")
        
        print (f"You are currently in room {self.room}")


class Thing:
    def __init__ (self, xCoord, yCoord):
        self.xCoord = xCoord
        self.yCoord = yCoord

    def render (self):
        pass

# Thing
class Thing:
    def __init__ (self, xCoord, yCoord):
        self.xCoord = xCoord
        self.yCoord = yCoord

    def render (self):
        pass
        
# Room 
class Room (Thing):
    def __init__ (self, name, xCoord, yCoord, doors) :
        super().__init__(xCoord, yCoord)
        self.doors = doors

    def render (self):
        global WINDOW
        room = pygame.Rect(self.xCoord, self.yCoord, 200, 200)

        pygame.draw.rect(WINDOW, ROOMCOLOR, room)


# Status Bar
class StatusBar (Thing):
    def __init__ (self, xCoord, yCoord, percentage):
        super.__init__ (self.xCoord, self.yCoord)
        self.percentage = percentage
    
    def render (self):
        global WINDOW
        done = pygame.Rect(self.xCoord, self.yCoord, 200, 200)
        todo = pygame.Rect(self.xCoord, self.yCoord, 10, 60)

        pygame.draw.rect(WINDOW, STATUSBARDONE, done)
        pygame.draw.rect(WINDOW, STATUSBARTODO, todo)

# Functions


# Main
def main () : 
    adventurer = Adventurer ()
    adventurer.set_up_character ()
    adventurer.describe ()
    
    rooms = []
    entryRoom = Room ("Entry", [0, 1, 0, 1])
    rooms.append(entryRoom)
    entryRoom.describe()


    return True

main ()
