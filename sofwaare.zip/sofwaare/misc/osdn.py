# Input
foo = [4, 42, 1337, 9, 2, 6, 7, 21, 26, 5, 314]
print (foo)
print ("")

# Processing
#number = 0
#if number >= 12:
#    foo[number] *= 2
#    number += 1
doubled = []

for i in foo:
    doubled.append(i*2)

# Output
print(doubled)