# Input
foo = [4, 42, 1337, 9, 2, 6, 7, 21, 26, 5, 314]
print (foo)
print ("")

# Processing
num1 = 0
num2 = 1

for i in foo:
    if foo[num1] > foo[num2]:
        pass

# Output
