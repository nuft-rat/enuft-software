import pygame, sys, random
from pygame.locals import *
pygame.init()
 
# Colours
BACKGROUND = (255, 255, 255)
BOX = (200, 50, 255)
HEXAGON = (130, 200, 175)
 
# Game Setup
FPS = 60
fpsClock = pygame.time.Clock()
WINDOW_WIDTH = 400
WINDOW_HEIGHT = 300
 
WINDOW = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption('My Game!')
 
# classes
# hexbutton (the facade)
class HexButton: 
    def __init__ (self, coordinates) :
        self.Xcoordinate = coordinates[0]
        self.Ycoordinate = coordinates[1]
        self.squareColour = BOX
        self.hexagonColour = HEXAGON
        self.hexagon = Hexagon(self.Xcoordinate, self.Ycoordinate + 5, self.hexagonColour)
        self.square = Square(self.Xcoordinate + 85, self.Ycoordinate, self.squareColour)

    def render (self) :
            self.square.render()
            self.hexagon.render()
#shape
class Shape:
    def __init__ (self, xCoord, yCoord, colour):
        self.colour = colour
        self.xCoord = xCoord
        self.yCoord = yCoord

    def setCoord (self, xCoord, yCoord):
        if xCoord > WINDOW_WIDTH - 100:
            print ("error, trying to get a button off the right side of the screen")
        else:
            self.xCoord = xCoord
#square
class Square (Shape):
    def __init__ (self, xCoord, yCoord, colour):
        super().__init__ (self, xCoord, yCoord, colour)
    
    def render (self) :
        pass

#hexanon
class hexagon (Shape):
    def __init__ (self, xCoord, yCoord, colour):
        super().__init__ (self, xCoord, yCoord, colour)
    
    def render (self) :
        pass

# The main function that controls the game
def main () :
    looping = True

    # The main game loop
    while looping :
        # Get inputs
        for event in pygame.event.get() :
            if event.type == QUIT :
                pygame.quit()
                sys.exit()

        # Processing


        # Render elements of the game
        WINDOW.fill(BACKGROUND)

        pygame.display.update()
        fpsClock.tick(FPS)
        
main()